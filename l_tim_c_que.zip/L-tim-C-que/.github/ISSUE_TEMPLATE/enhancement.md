---
name: Enhancement
about: Enhance a feature for the application
title: ""
labels: enhancement
assignees: ''

---

**Requested by**: <!-- check AT LEAST one box -->
- [ ] Development Team
- [ ] Instructor

<!-- Add a clear and concise description of the enhancement, including a motivation: why do you think this will be useful?  -->



## Additional comments
<!-- Add further context that you think might be relevant. -->
