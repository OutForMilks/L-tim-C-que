package com.example.l_tim_c_que.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.l_tim_c_que.repository.MealRepository

/**
 * Factory for creating a [RandomViewModel] with a constructor that takes a [MealRepository].
 *
 * @param repository The repository for meal data.
 */
class RandomViewModelFactory (
    private  val repository: MealRepository
): ViewModelProvider.Factory {

    /**
     * Creates a new instance of the given `Class`.
     *
     * @param modelClass A `Class` whose instance is requested.
     * @return A newly created ViewModel.
     * @throws IllegalArgumentException if the given `modelClass` is not a [RandomViewModel].
     */
    override fun <T: ViewModel> create(modelClass: Class<T>): T {
        // Check if the requested ViewModel class is assignable from RandomViewModel
        if(modelClass.isAssignableFrom(RandomViewModel::class.java)) {
            // If it is, create an instance of RandomViewModel, passing the repository.
            return RandomViewModel(repository) as T //its safe since there is an if statement to check
        }
        // If the requested ViewModel is not RandomViewModel, throw an exception.
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}